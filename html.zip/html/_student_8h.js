var _student_8h =
[
    [ "Student", "struct_student.html", "struct_student" ]
];