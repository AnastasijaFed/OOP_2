var _student_deque_8h =
[
    [ "StudentDeque", "struct_student_deque.html", "struct_student_deque" ],
    [ "averageDeque", "_student_deque_8h.html#aef1593e2f1751fcba421f1d162f00aae", null ],
    [ "calculateFinalGradesAverageDeque", "_student_deque_8h.html#ac3b8b635f2aa9d6d249e13cb0768deb3", null ],
    [ "readFileDeque", "_student_deque_8h.html#a8cfa91f77f0e992e73de8c1e467a9dbb", null ],
    [ "sortDeque", "_student_deque_8h.html#a604ce1291cf7a6d3b2b4db67b393c03f", null ],
    [ "splitToGroupsDeque", "_student_deque_8h.html#ac6be9abce46042b5d3d7d4ab79fe0cad", null ],
    [ "strategyThreeDeque", "_student_deque_8h.html#a59c2cfa884424dd09c9d972ac4753288", null ],
    [ "strategyTwoDeque", "_student_deque_8h.html#a572d282e21721eb6d4c2d5f772b6b38c", null ]
];