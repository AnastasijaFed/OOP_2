var _student_list_8cpp =
[
    [ "averageList", "_student_list_8cpp.html#a3e193de3a1c9227ced01289b323f080d", null ],
    [ "calculateFinalGradesAverageList", "_student_list_8cpp.html#ad5e095e7accdbc1f34e71c49d9a4b6c8", null ],
    [ "readFileLists", "_student_list_8cpp.html#ae2ebd643be3860dfe931c73e9e3b661c", null ],
    [ "sortList", "_student_list_8cpp.html#a0e55706d8673202b896fd78fe3ea9a00", null ],
    [ "splitInTwo", "_student_list_8cpp.html#ab90064f9df2e5f0fb1e2e93be327885f", null ],
    [ "strategyThreeList", "_student_list_8cpp.html#a90a42436c833a3565d3c80598c73c703", null ],
    [ "strategyTwoList", "_student_list_8cpp.html#ae35608b09068156c174ed3d0adba8834", null ]
];