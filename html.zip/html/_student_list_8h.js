var _student_list_8h =
[
    [ "StudentList", "struct_student_list.html", "struct_student_list" ],
    [ "averageList", "_student_list_8h.html#a3e193de3a1c9227ced01289b323f080d", null ],
    [ "calculateFinalGradesAverageList", "_student_list_8h.html#ad5e095e7accdbc1f34e71c49d9a4b6c8", null ],
    [ "readFileLists", "_student_list_8h.html#ae2ebd643be3860dfe931c73e9e3b661c", null ],
    [ "sortList", "_student_list_8h.html#a0e55706d8673202b896fd78fe3ea9a00", null ],
    [ "splitInTwo", "_student_list_8h.html#ab90064f9df2e5f0fb1e2e93be327885f", null ],
    [ "strategyThreeList", "_student_list_8h.html#a90a42436c833a3565d3c80598c73c703", null ],
    [ "strategyTwoList", "_student_list_8h.html#ae35608b09068156c174ed3d0adba8834", null ]
];