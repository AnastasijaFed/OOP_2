var class_human =
[
    [ "Human", "class_human.html#a1e7ebe2c710e3026b8f8f0882e2a0475", null ],
    [ "Human", "class_human.html#ae9064f4eaf69b2822c6cfcfddb841d61", null ],
    [ "~Human", "class_human.html#ade867e9b0d9afafc935d60cea53fd595", null ],
    [ "Human", "class_human.html#a92f0bc218a2807745a163cbfeff39e99", null ],
    [ "getName", "class_human.html#a69a27e7bc681ed227041ea40e894e401", null ],
    [ "getSurname", "class_human.html#aaebff100983c200379f837c9aff67672", null ],
    [ "operator=", "class_human.html#a7a91332c45042cecd2100f4878218e27", null ],
    [ "printInfo", "class_human.html#a9e6149d088adc39beac429e445523409", null ],
    [ "setName", "class_human.html#af188427d3a57ad5a2812feaa6880abd7", null ],
    [ "setSurname", "class_human.html#a2a0df98fc66b2db7b20baa773045b508", null ],
    [ "name", "class_human.html#a13799d570913a7ae5427bb15c4d81bb0", null ],
    [ "surname", "class_human.html#a4d06702dc92ea4498bfcdf5e8efe8971", null ]
];