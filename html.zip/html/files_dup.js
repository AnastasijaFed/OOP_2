var files_dup =
[
    [ "cmake-build-debug", "dir_95e29a8b8ee7c54052c171a88bb95675.html", "dir_95e29a8b8ee7c54052c171a88bb95675" ],
    [ "functions.cpp", "functions_8cpp.html", "functions_8cpp" ],
    [ "functions.h", "functions_8h.html", "functions_8h" ],
    [ "Human.cpp", "_human_8cpp.html", null ],
    [ "Human.h", "_human_8h.html", "_human_8h" ],
    [ "Student.cpp", "_student_8cpp.html", "_student_8cpp" ],
    [ "Student.h", "_student_8h.html", "_student_8h" ],
    [ "StudentClass.cpp", "_student_class_8cpp.html", "_student_class_8cpp" ],
    [ "StudentClass.h", "_student_class_8h.html", "_student_class_8h" ],
    [ "StudentDeque.cpp", "_student_deque_8cpp.html", "_student_deque_8cpp" ],
    [ "StudentDeque.h", "_student_deque_8h.html", "_student_deque_8h" ],
    [ "StudentList.cpp", "_student_list_8cpp.html", "_student_list_8cpp" ],
    [ "StudentList.h", "_student_list_8h.html", "_student_list_8h" ]
];