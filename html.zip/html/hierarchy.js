var hierarchy =
[
    [ "Human", "class_human.html", [
      [ "StudentClass", "class_student_class.html", null ]
    ] ],
    [ "Student", "struct_student.html", null ],
    [ "StudentDeque", "struct_student_deque.html", null ],
    [ "StudentList", "struct_student_list.html", null ]
];