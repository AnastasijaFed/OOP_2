var searchData=
[
  ['test_0',['test',['../functions_8cpp.html#ad1adc684b1eb66189aa5ef4c03045e17',1,'test():&#160;functions.cpp'],['../functions_8h.html#ad1adc684b1eb66189aa5ef4c03045e17',1,'test():&#160;functions.cpp']]],
  ['testclass_1',['testClass',['../class_student_class.html#a341b12ab20c16e25797c5ae42e82de96',1,'StudentClass']]]
];
