var searchData=
[
  ['_7ehuman_0',['~Human',['../class_human.html#ade867e9b0d9afafc935d60cea53fd595',1,'Human']]],
  ['_7estudentclass_1',['~StudentClass',['../class_student_class.html#a99a3c3fc8393fc9fa8f31eed20b5e555',1,'StudentClass']]]
];
