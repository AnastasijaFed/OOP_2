var searchData=
[
  ['loadfromfile_0',['loadFromFile',['../functions_8cpp.html#ada522c3bef7282bc87990581ba55a911',1,'loadFromFile(const string &amp;filename):&#160;functions.cpp'],['../functions_8h.html#aea65d9ad2deb8bb141632d960845d934',1,'loadFromFile(const string &amp;fileName):&#160;functions.cpp']]],
  ['loadfromfileclass_1',['loadFromFileClass',['../class_student_class.html#aa6b024aca79bec6856c917916713aca6',1,'StudentClass']]],
  ['logduration_2',['logDuration',['../class_student_class.html#aa8f5082ec6388864ef7ad0f5acc021c4',1,'StudentClass::logDuration()'],['../functions_8cpp.html#a9213b849c7bdd6fe63538b157cd7de30',1,'logDuration(const string &amp;message, const high_resolution_clock::time_point &amp;start, const high_resolution_clock::time_point &amp;stop):&#160;functions.cpp'],['../functions_8h.html#a9dc842130c831d5ee5e3172447cc333b',1,'logDuration(const string &amp;message, const auto &amp;start, const auto &amp;stop):&#160;functions.h']]]
];
