var searchData=
[
  ['name_0',['name',['../class_human.html#a13799d570913a7ae5427bb15c4d81bb0',1,'Human::name'],['../struct_student.html#a9aeb48a925f370292564def17482f0ec',1,'Student::name'],['../class_student_class.html#ae89fc122c09534d589919b59d66eede7',1,'StudentClass::name'],['../struct_student_deque.html#a89f76efc0ef68ce4578d103192ba645b',1,'StudentDeque::name'],['../struct_student_list.html#a2c0c3fc8e72fb97664e1fea4f6fff74f',1,'StudentList::name']]]
];
