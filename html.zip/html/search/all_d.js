var searchData=
[
  ['platform_5fid_0',['PLATFORM_ID',['../_c_make_c_compiler_id_8c.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCXXCompilerId.cpp']]],
  ['printinfo_1',['printInfo',['../class_human.html#a9e6149d088adc39beac429e445523409',1,'Human::printInfo()'],['../class_student_class.html#a839ddc3b398ce49141a63ee5240ef860',1,'StudentClass::printInfo()']]],
  ['printstudentlist_2',['printStudentList',['../functions_8cpp.html#ae6d99ff6b8dd4a082d1ca14ed297775c',1,'printStudentList(vector&lt; Student &gt; &amp;students):&#160;functions.cpp'],['../functions_8h.html#ae6d99ff6b8dd4a082d1ca14ed297775c',1,'printStudentList(vector&lt; Student &gt; &amp;students):&#160;functions.cpp']]],
  ['printstudentlistclass_3',['printStudentListClass',['../class_student_class.html#ab661a36ec5aa308938ddf8e7be9d1471',1,'StudentClass']]]
];
