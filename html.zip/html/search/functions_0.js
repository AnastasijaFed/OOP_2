var searchData=
[
  ['addstudents_0',['addStudents',['../functions_8cpp.html#a0298bcf61457c3adc9f90080a32a4bb1',1,'addStudents(vector&lt; Student &gt; students):&#160;functions.cpp'],['../functions_8h.html#a0298bcf61457c3adc9f90080a32a4bb1',1,'addStudents(vector&lt; Student &gt; students):&#160;functions.cpp']]],
  ['addstudentsobjects_1',['addStudentsObjects',['../class_student_class.html#a858904f881127db1c62933fb747983b0',1,'StudentClass']]],
  ['average_2',['average',['../functions_8cpp.html#a55394678cb87a341f77eb1ebcddba71a',1,'average(const Student &amp;student):&#160;functions.cpp'],['../functions_8h.html#a55394678cb87a341f77eb1ebcddba71a',1,'average(const Student &amp;student):&#160;functions.cpp']]],
  ['averageclass_3',['averageClass',['../class_student_class.html#a10e6076363b5dc6b42f363434323c7f6',1,'StudentClass']]],
  ['averagedeque_4',['averageDeque',['../_student_deque_8cpp.html#aef1593e2f1751fcba421f1d162f00aae',1,'averageDeque(const StudentDeque &amp;student):&#160;StudentDeque.cpp'],['../_student_deque_8h.html#aef1593e2f1751fcba421f1d162f00aae',1,'averageDeque(const StudentDeque &amp;student):&#160;StudentDeque.cpp']]],
  ['averagelist_5',['averageList',['../_student_list_8cpp.html#a3e193de3a1c9227ced01289b323f080d',1,'averageList(const StudentList &amp;student):&#160;StudentList.cpp'],['../_student_list_8h.html#a3e193de3a1c9227ced01289b323f080d',1,'averageList(const StudentList &amp;student):&#160;StudentList.cpp']]]
];
