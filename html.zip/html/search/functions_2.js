var searchData=
[
  ['generategrades_0',['generateGrades',['../functions_8cpp.html#a249b19b2c7710d82881846930b2a58f8',1,'generateGrades(vector&lt; Student &gt; &amp;students):&#160;functions.cpp'],['../functions_8h.html#a249b19b2c7710d82881846930b2a58f8',1,'generateGrades(vector&lt; Student &gt; &amp;students):&#160;functions.cpp']]],
  ['generategradesclass_1',['generateGradesClass',['../class_student_class.html#a8ff09df67d61b30703042027bfb3d8f4',1,'StudentClass']]],
  ['generaterandomstudents_2',['generateRandomStudents',['../functions_8cpp.html#a8c77929e98a78a8628c26fbe642ff8b4',1,'generateRandomStudents(int count):&#160;functions.cpp'],['../functions_8h.html#a8c77929e98a78a8628c26fbe642ff8b4',1,'generateRandomStudents(int count):&#160;functions.cpp']]],
  ['generaterandomstudentsclass_3',['generateRandomStudentsClass',['../class_student_class.html#a7638a1b6ddf17130a851550fdd3d7914',1,'StudentClass']]],
  ['generatestudentsfile_4',['generateStudentsFile',['../functions_8cpp.html#ae49efe61672c4ec5238b80e1b94670d8',1,'generateStudentsFile(int numberOfStudents):&#160;functions.cpp'],['../functions_8h.html#ae49efe61672c4ec5238b80e1b94670d8',1,'generateStudentsFile(int numberOfStudents):&#160;functions.cpp']]],
  ['generatestudentsfileclass_5',['generateStudentsFileClass',['../class_student_class.html#aba925404a02e0e99d13e0de6242693eb',1,'StudentClass']]],
  ['getexamgrades_6',['getExamGrades',['../class_student_class.html#a3067a7f53390ee884194d44952f54dc8',1,'StudentClass']]],
  ['getfinalgrade_7',['getFinalGrade',['../class_student_class.html#af3ea0733c9d6994193ee1ec36ff5951c',1,'StudentClass']]],
  ['getgrades_8',['getGrades',['../class_student_class.html#a4f4798cf6496d1037d073f055abea6c7',1,'StudentClass']]],
  ['getname_9',['getName',['../class_human.html#a69a27e7bc681ed227041ea40e894e401',1,'Human']]],
  ['getsurname_10',['getSurname',['../class_human.html#aaebff100983c200379f837c9aff67672',1,'Human']]]
];
