var searchData=
[
  ['human_0',['Human',['../class_human.html#a1e7ebe2c710e3026b8f8f0882e2a0475',1,'Human::Human()=default'],['../class_human.html#ae9064f4eaf69b2822c6cfcfddb841d61',1,'Human::Human(string name, string surname)'],['../class_human.html#a92f0bc218a2807745a163cbfeff39e99',1,'Human::Human(Human &amp;&amp;student) noexcept']]]
];
