var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../_student_class_8cpp.html#ab037e461160cac0bbcebf9ab4d6004ac',1,'StudentClass.cpp']]],
  ['operator_3d_1',['operator=',['../class_human.html#a7a91332c45042cecd2100f4878218e27',1,'Human::operator=()'],['../class_student_class.html#aec6b9104787d42fade2d7b8beb235742',1,'StudentClass::operator=(const StudentClass &amp;student)'],['../class_student_class.html#ae8a2f01bbe3c37a46e46b6f350b8d11c',1,'StudentClass::operator=(StudentClass &amp;&amp;student) noexcept']]]
];
