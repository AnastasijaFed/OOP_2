var searchData=
[
  ['printinfo_0',['printInfo',['../class_human.html#a9e6149d088adc39beac429e445523409',1,'Human::printInfo()'],['../class_student_class.html#a839ddc3b398ce49141a63ee5240ef860',1,'StudentClass::printInfo()']]],
  ['printstudentlist_1',['printStudentList',['../functions_8cpp.html#ae6d99ff6b8dd4a082d1ca14ed297775c',1,'printStudentList(vector&lt; Student &gt; &amp;students):&#160;functions.cpp'],['../functions_8h.html#ae6d99ff6b8dd4a082d1ca14ed297775c',1,'printStudentList(vector&lt; Student &gt; &amp;students):&#160;functions.cpp']]],
  ['printstudentlistclass_2',['printStudentListClass',['../class_student_class.html#ab661a36ec5aa308938ddf8e7be9d1471',1,'StudentClass']]]
];
