var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student_class.html#ae945479ba417fd15ad2b06c4695ab762',1,'StudentClass']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student_class.html#aea50430d6f8fd308cae6ac1806dbe5f8',1,'StudentClass']]]
];
