var indexSectionsWithContent =
{
  0: "_acdefghilmnoprstw~",
  1: "hs",
  2: "cfhrs",
  3: "acghlmoprstw~",
  4: "efgins",
  5: "o",
  6: "_acdhps",
  7: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Visi",
  1: "Klasės",
  2: "Failai",
  3: "Funkcijos",
  4: "Kintamieji",
  5: "Draugai",
  6: "Apibrėžimai",
  7: "Puslapiai"
};

