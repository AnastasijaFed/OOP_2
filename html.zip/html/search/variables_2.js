var searchData=
[
  ['grades_0',['grades',['../struct_student.html#a8e13e735623b5364bbb4fe2edfee25f8',1,'Student::grades'],['../class_student_class.html#a79dc9af175e5798b98bfb90937bcceef',1,'StudentClass::grades'],['../struct_student_deque.html#a56a27e5dd7976c832e71cb3e974c4cfd',1,'StudentDeque::grades'],['../struct_student_list.html#a48c4fb13492059a6a0d1aa04ced10adf',1,'StudentList::grades']]]
];
