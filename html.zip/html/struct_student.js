var struct_student =
[
    [ "exam_grade", "struct_student.html#a4c90c1e3d8b78da21cb6da93b2d08b3e", null ],
    [ "final_grade", "struct_student.html#a0db5fb34c74814a4efa4317944bb719b", null ],
    [ "grades", "struct_student.html#a8e13e735623b5364bbb4fe2edfee25f8", null ],
    [ "name", "struct_student.html#a9aeb48a925f370292564def17482f0ec", null ],
    [ "surname", "struct_student.html#a65b61fc4c68497e904b065c43f7a6967", null ]
];