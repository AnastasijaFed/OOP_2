var struct_student_deque =
[
    [ "exam_grade", "struct_student_deque.html#acbb9fa23433c3c82bb766aa2db223b73", null ],
    [ "final_grade", "struct_student_deque.html#ab8d5dff4efbd8d4969d3c40e6d24664b", null ],
    [ "grades", "struct_student_deque.html#a56a27e5dd7976c832e71cb3e974c4cfd", null ],
    [ "name", "struct_student_deque.html#a89f76efc0ef68ce4578d103192ba645b", null ],
    [ "surname", "struct_student_deque.html#a2978bd181abf789f1909b2162aa32229", null ]
];