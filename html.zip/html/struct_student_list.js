var struct_student_list =
[
    [ "exam_grade", "struct_student_list.html#a84b8b4d5730b2f20f389dd7324f00ee4", null ],
    [ "final_grade", "struct_student_list.html#af77f17a3db24381a9576b9eb249cb3db", null ],
    [ "grades", "struct_student_list.html#a48c4fb13492059a6a0d1aa04ced10adf", null ],
    [ "name", "struct_student_list.html#a2c0c3fc8e72fb97664e1fea4f6fff74f", null ],
    [ "surname", "struct_student_list.html#a88c0535b654a868890e5e26dd32badd3", null ]
];